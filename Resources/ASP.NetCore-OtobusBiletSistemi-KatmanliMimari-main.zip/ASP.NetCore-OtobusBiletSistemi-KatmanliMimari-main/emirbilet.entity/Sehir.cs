﻿using System;
using System.Collections.Generic;
using System.Text;

namespace emirbilet.entity
{
    public class Sehir
    {
        public int SehirId { get; set; }
        public string SehirAd { get; set; }
        
    }
}

